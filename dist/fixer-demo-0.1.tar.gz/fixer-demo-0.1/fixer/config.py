BASE_PATH = "https://api.apilayer.com/fixer/latest?base=USD&apikey="
