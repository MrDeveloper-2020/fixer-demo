from setuptools import setup

setup(
    name='fixer-demo',
    version='0.1',
    description='Fixer service demo package',
    url='#',
    author='Alireza',
    author_email='Alireza2020abbasian@gmail.com',
    license='MIT',
    packge=['fixer'],
    zip_safe=False
)
